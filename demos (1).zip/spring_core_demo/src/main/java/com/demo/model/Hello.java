package com.demo.model;

public class Hello {

	private String message;
	public Hello() {
		System.out.println("no param constructor called");
	}
	public Hello(String message) {
		this.message=message;
		System.out.println("param constructor called");
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		System.out.println("setter called");
		this.message = message;
	}
	
	public void init() {
		System.out.println("init() from Hello class");
	}
	
	public void destroy() {
		System.out.println("destroy from Hello class");
	}
	
}
