package com.player.service;

import java.util.List;

import com.player.Player;

public interface PlayerService {

	public Player addPlayer(Player player);
	public Player getPlayerById(int id);
	public Player updatePlayer(Player player);
	public void deletePlayer(int id);
	public List<Player> getAllPlayers();
	public List<Player> getPlayersByName(String name);
}
