package com.player.service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.player.Player;

public class PlayerServiceImpl implements PlayerService {

	private static Map<Integer, Player> playerMap=new LinkedHashMap<>();
	private static int idCount=0;
	@Override
	public Player addPlayer(Player player) {
		player.setId(++idCount);
		playerMap.put(player.getId(), player);
		//System.out.println(playerMap);
		return player;
	}

	@Override
	public Player getPlayerById(int id) {
		return playerMap.get(id);
	}

	@Override
	public Player updatePlayer(Player player) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deletePlayer(int id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Player> getAllPlayers() {
		
		return new ArrayList<>(playerMap.values());
	}

	@Override
	public List<Player> getPlayersByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

}
