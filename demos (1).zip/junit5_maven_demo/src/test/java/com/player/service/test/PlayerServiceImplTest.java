package com.player.service.test;

import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.player.Player;
import com.player.service.PlayerService;
import com.player.service.PlayerServiceImpl;

class PlayerServiceImplTest {
private static PlayerService service;
	@BeforeAll
	static void  setUp() {
		service=new PlayerServiceImpl();
		service.addPlayer(new Player("rajat"));
	}

	@Test
	void testAddPlayer() {
		Player player=new Player();
		player.setName("dinesh");
		player=service.addPlayer(player);
		
		Assertions.assertEquals(2, player.getId());
	}

	@Test
	void testGetPlayerById() {
		Player playerActual=service.getPlayerById(1);
		Player playerExpected=new Player(1, "rajat");
		//System.out.println("playerActual = "+playerActual);
		Assertions.assertEquals(playerExpected, playerActual);
	}

	@Test
	void testUpdatePlayer() {
		fail("Not yet implemented");
	}

	@Test
	void testDeletePlayer() {
		fail("Not yet implemented");
	}

	@Test
	void testGetAllPlayers() {
		int actual=service.getAllPlayers().size();
		Assertions.assertEquals(1, actual);
	}

	@Test
	void testGetPlayersByName() {
		fail("Not yet implemented");
	}

}
