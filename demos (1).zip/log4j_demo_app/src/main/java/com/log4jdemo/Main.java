package com.log4jdemo;

import org.apache.log4j.Logger;

public class Main {
	private static Logger log = Logger.getLogger(Main.class);

	public static void main(String[] args) {
	log.trace("Hello Trace");
	log.debug("Hello Debug");
	log.info("Hello Info");
	log.warn("Hello Warn");
	log.error("Hello ERROR");
	log.fatal("Hello FATAL");
	}

}
