package com.hello.test;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class JunitLifeCycleTest {

	@BeforeAll  //junit4 -> @BeforeClass
	public static void beforeAllMethods() {
		System.out.println("BeforeAll This is first method to be executed and only once");
	}
	
	@BeforeEach //junit4 ->@Before
	public void beforeEachTestMethod() {
		System.out.println("BeforeEach Test cases I will be executed");
	}
	
	@Test
	public void testHi() {
		System.out.println("Hi from Test Case");
	}
	
	@Test
	public void testHello() {
		System.out.println("Hello from Test Case");
	}
	
	@AfterEach //junit4 -> @After
	public void afterEachTestMethod() {
		System.out.println("AfterEach Test cases I will be executed");
	}
	
	@AfterAll // junit4 -> @AfterClass
	public static void afterAllMethodsInClass() {
		System.out.println("AfterAll methods in class I will be executed once");
	}
	
}
