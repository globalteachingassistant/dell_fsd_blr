package com.hello.test;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.hello.HelloWorld;

public class HelloWorldTest {

	private static HelloWorld hello;
	
	@BeforeAll
	public static void setUp() {
		hello=new HelloWorld();
	}
	
	@Test
	public void testSayHello() {
	//	String result=hello.sayHello();
		Assertions.assertEquals("Hello World", hello.sayHello());
	}
	
	@Test
	public void testSayHelloWithName() {
		String name="Meera";
		Assertions.assertEquals("Hello "+name, hello.sayHello(name));
	}
}
