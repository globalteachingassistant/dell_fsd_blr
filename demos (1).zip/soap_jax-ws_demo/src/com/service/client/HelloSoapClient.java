package com.service.client;

import java.net.MalformedURLException;
import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;

import com.service.HelloSoapService;

public class HelloSoapClient {

	public static void main(String[] args) {
		try {
			URL url=new URL("http://localhost:8000/hello?wsdl");
			
			QName qName=new QName("http://impl.service.com/", "HelloSoapServiceImplService");
			Service service=Service.create(url, qName);
			HelloSoapService hss=service.getPort(HelloSoapService.class);
			System.out.println(hss.sayHello());
			System.out.println(hss.sayHi("Ashutosh"));
		} catch (MalformedURLException e) {
			System.out.println("Exception with URL "+e.getMessage());
		}

	}

}
