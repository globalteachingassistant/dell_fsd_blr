package com.demo.player;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.demo.player.dao.PlayerDAO;
import com.demo.player.model.Player;

public class PlayerMain {

	public static void main(String[] args) {
	ApplicationContext context=new ClassPathXmlApplicationContext("hibernatebeans.xml");
	
	PlayerDAO dao=(PlayerDAO) context.getBean("dao");
	System.out.println(dao.addPlayer(new Player("test player hib", "SpringHib", 23, 1121121111)));
	
	System.out.println(dao.getPlayerById(10));
	
	List<Player> playerList=dao.getAllPlayers();
	for(Player p:playerList) {
		System.out.println(p);
	}
	}

}
