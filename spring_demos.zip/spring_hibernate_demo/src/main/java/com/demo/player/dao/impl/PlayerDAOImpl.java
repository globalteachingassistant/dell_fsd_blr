package com.demo.player.dao.impl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.demo.player.dao.PlayerDAO;
import com.demo.player.model.Player;

public class PlayerDAOImpl implements PlayerDAO {

	private SessionFactory factory;
	
	public void setFactory(SessionFactory factory) {
		this.factory = factory;
	}

	@Override
	public Player addPlayer(Player player) {
		Session session=factory.openSession();
		Transaction transaction=session.beginTransaction();
		session.save(player);
		transaction.commit();
		session.close();
		return player;
	}

	@Override
	public List<Player> getAllPlayers() {
		Session session=factory.openSession();
		Transaction transaction=session.beginTransaction();
		List<Player> playerList=session.createQuery("from com.demo.player.model.Player").list();
		transaction.commit();
		session.close();
		return playerList;
	}

	@Override
	public Player getPlayerById(int id) {
		Session session=factory.openSession();
		Transaction transaction=session.beginTransaction();
		Player player=(Player) session.get(Player.class, id);
		transaction.commit();
		session.close();
		return player;
	}

	@Override
	public void removePlayer(int id) {
		Session session=factory.openSession();
		Transaction transaction=session.beginTransaction();
		transaction.commit();
		session.close();
		
	}

	@Override
	public Player getPlayerByContact(long contact) {
		Session session=factory.openSession();
		Transaction transaction=session.beginTransaction();
		transaction.commit();
		session.close();
		return null;
	}

}
