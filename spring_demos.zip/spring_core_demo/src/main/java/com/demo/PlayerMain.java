package com.demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.demo.model.Player;

public class PlayerMain {

	public static void main(String[] args) {
		
		ApplicationContext context=new ClassPathXmlApplicationContext("playerbeans.xml");
//		Player p1=context.getBean(Player.class);
		System.out.println("Printing id=p1");
		Player player1=(Player) context.getBean("p1");
		System.out.println(player1);
		
		System.out.println("\nPrinting id=p2");
		Player player2=(Player) context.getBean("p2");
		System.out.println(player2);
		System.out.println(player2.hashCode());
		System.out.println("\nPrinting id=p2 Again with bean get to check hashcode");
		Player player3=(Player) context.getBean("p2");
		System.out.println(player3);
		System.out.println(player3.hashCode());
		System.out.println("\nPrinting id=p3");
		Player player4=(Player) context.getBean("p3");
		System.out.println(player4);
		System.out.println("\nPrinting id=p4");
		Player player5=(Player) context.getBean("p4");
		System.out.println(player5);
		
	}

}
