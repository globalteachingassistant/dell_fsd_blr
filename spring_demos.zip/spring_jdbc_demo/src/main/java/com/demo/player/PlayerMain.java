package com.demo.player;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.demo.player.dao.PlayerDAO;
import com.demo.player.model.Player;

public class PlayerMain {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("jdbcbean.xml");
		
		PlayerDAO playerDAO=(PlayerDAO) context.getBean("dao");
	
//		List<Player> playerList=playerDAO.getAllPlayers();
//		for(Player p:playerList) {
//			System.out.println(p);
//		}
		
		//playerDAO.addPlayer(new Player("Template", "Spring", 4, 900123121L));
		
		System.out.println(playerDAO.getPlayerById(10));
		
		//Try update delete and other options

	}

}
