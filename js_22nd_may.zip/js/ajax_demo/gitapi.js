

function getAllUsers(){
    let xhr=new XMLHttpRequest;
    let url="https://api.github.com/users"
    xhr.open('GET',url,true);
    xhr.onload=function(){
        if(this.status===200 && this.readyState===4){
            //console.log(this.responseText);
            let res=JSON.parse(this.responseText);
            let data="<table><tr class='table-info'><th>Login Name</th>"
            data=data+"<th>Avatar Image</th></tr>"
            res.forEach(element => {
               data=data+"<tr><td>"+element.login+"</td>"; 
               data=data+"<td><img class='rounded-circle' width=100 height=100 src='"+element.avatar_url+"'/></td></tr>";
            });
            data=data+"</table>"
            document.getElementById("data").innerHTML=data;
        }
    }
    xhr.send();
}

function getuserById(){
    let xhr=new XMLHttpRequest;
    let login=document.getElementById("login").value;
    let url="https://api.github.com/users/"+login;
    xhr.open('GET',url,true);
    xhr.onload=function(){
        if(this.status===200 && this.readyState===4){
            //console.log(this.responseText);
            let res=JSON.parse(this.responseText);
            let data="<table><tr class='table-info'><th>Login Name</th>"
            data=data+"<th>Avatar Image</th></tr>"
           // res.forEach(element => {
               data=data+"<tr><td>"+res.login+"</td>"; 
               data=data+"<td><img class='rounded-circle' width=100 height=100 src='"+res.avatar_url+"'/></td></tr>";
          //  });
            data=data+"</table>"
            document.getElementById("data").innerHTML=data;
        }
    }
    xhr.send(); 
}