

function getAllUsers(){
   fetch('https://api.github.com/users')
   .then(res=>res.json())
   .then(data=>console.log(data))
}

function getuserById(){
    let login=document.getElementById("login").value;
    let url="https://api.github.com/users/"+login;
    
    fetch(url)
   .then(res=>res.json())
   .then(data=>console.log(data))
   
}