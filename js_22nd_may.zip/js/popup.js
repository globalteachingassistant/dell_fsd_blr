function alertDemo(){
    let name=document.getElementById("name").value;
    alert("Hello "+name);
}

function confirmDemo(){
    let name=document.getElementById("name").value;
    let answer=confirm("Is this your name? "+name);
    if(answer===true){
        document.write("user confirmed his name as "+name);
    }else{
        document.write("user did not confirm his name as "+name);
    }
}

function promptDemo(){
    let name=document.getElementById("name").value;
    let email=prompt("Enter your email to continue ");
    document.write("Hello "+name+" your email is "+email)
}