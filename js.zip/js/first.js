document.write("<h1>Hello from External Js</h1>")
console.log("hello Js from external")
document.getElementById("one").innerText="<h1>Hello Div with innerText</h1>"
document.getElementById("two").innerHTML="<h1>Hello Div with innerHTML</h1>"


function hello(){
    document.getElementById("three").innerHTML="<h1>Hello function</h1>";
}