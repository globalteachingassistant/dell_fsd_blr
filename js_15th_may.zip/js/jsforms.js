function validate(){
    var name=document.getElementById("name").value;
    var message="";
    if(name==""){
        message="name cannot be empty";
    }
    document.getElementById("err").innerText=message;

    var gender=document.getElementsByName("gender");
    var flag=false;
    for(let i=0;i<gender.length;i++){
        if(gender[i].checked){
            flag=true;
            break;
        }
    }
    var genMessage="";
    if(!flag){
        genMessage="Please select avalid gender";
    }else{
        genMessage="";
    }
    document.getElementById("errGen").innerText=genMessage;
    if(message=="" && genMessage==""){
        return true;
    }else{
        return false;
    }
   
}