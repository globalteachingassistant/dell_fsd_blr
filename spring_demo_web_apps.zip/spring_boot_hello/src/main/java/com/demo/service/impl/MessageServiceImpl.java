package com.demo.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.dao.MessageDAO;
import com.demo.model.Message;
import com.demo.service.MessageService;


@Service
public class MessageServiceImpl implements MessageService{
//private static Map<Integer, Message> map=new HashMap<Integer, Message>();
//private static int count;
	@Autowired
	private MessageDAO dao;
	
	public Message createMessage(Message message) {
		//message.setId(++count);
		//map.put(count, message);
		return dao.save(message);
	}

	public Message getMessageById(int id) {
		
		//return map.get(id);
		return dao.findById(id).get();
	}

	public List<Message> getAllMessages() {
		
		//return new ArrayList<Message>(map.values());
		return dao.findAll();
	}

	public Message updateMessage(Message message) {
		//map.put(message.getId(), message);
		//return message;
		return dao.save(message);
	}

	public void removeMessage(int id) {
	
		//map.remove(id);
		dao.deleteById(id);
	}

}
